# ![logo](LINE-sm.png) LINE Python

*LINE Messaging's private API*

----

# JANGAN LUPA ADD [ADITMADZS BOT](http://line.me/ti/p/~aditmadzsbot)
# SC Sementara Sewaktu Waktu Akan Di Update

# Termux

```sh
$ apt update
$ apt upgrade
$ apt install python
$ pkg install python3
$ apt install git
$ git clone https://github.com/Aditmadzs/Selfbotpy3
$ cd Selfbotpy3
$ python -m pip install -r requirements.txt
$ python3 Aditmadzs.py
```

## VPS

```sh
$ git clone https://github.com/Aditmadzs/Selfbotpy3
$ cd Selfbotpy3
$ python3 -m pip install -r requirements.txt
$ python Aditmadzs.py
```

## Thanks To:
HelloWorld

